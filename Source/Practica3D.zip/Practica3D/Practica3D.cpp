// Fill out your copyright notice in the Description page of Project Settings.

#include "Practica3D.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Practica3D, "Practica3D" );
